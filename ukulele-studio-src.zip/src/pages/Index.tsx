import { UkuleleStudio } from "@/ukulele/components/UkuleleStudio";

const Index = () => {
  return <UkuleleStudio />;
};

export default Index;
